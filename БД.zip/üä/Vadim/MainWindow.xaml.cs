﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Vadim.Classes;
using Vadim.Book;
using Vadim.Reader;
using Vadim.Ticket;

namespace Vadim
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Classes.ClassFrame.frmObj = FrmLib;
            pngLogo.Visibility = Visibility.Visible;
        }

        private void BTNBooks_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new book());
            pngLogo.Visibility = Visibility.Hidden;
        }

        private void hgt1_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new reade());
            pngLogo.Visibility = Visibility.Hidden;
        }

        private void hgt10_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new ticket());
            pngLogo.Visibility = Visibility.Hidden;
        }
    }
}
