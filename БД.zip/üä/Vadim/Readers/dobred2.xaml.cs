﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Vadim.Reader;
using Vadim.Classes;

namespace Vadim.Readers
{
    /// <summary>
    /// Логика взаимодействия для dobred2.xaml
    /// </summary>
    public partial class dobred2 : Page
    {
        private ReaderBD _currentItem = new ReaderBD();
        public dobred2(ReaderBD selectedItem)
        {
            InitializeComponent();
            if (selectedItem != null)
            {
                _currentItem = selectedItem;
                Titletxt.Text = "Изменение";
            }
            // Создаём контекст
            DataContext = _currentItem;
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentItem.fio)) error.AppendLine("Укажите ФИО читателя");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.number))) error.AppendLine("Укажите номер");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.phone))) error.AppendLine("Укажите телефон");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.address))) error.AppendLine("Укажите адрес");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentItem.idReader == 0)
            {
                LibraryEntities.GetContext().ReaderBD.Add(_currentItem);
                try
                {
                    LibraryEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new reade());
                    MessageBox.Show("Новый читатель успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    LibraryEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new reade());
                    MessageBox.Show("Читатель успешно изменен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new reade());
        }
    }
}
