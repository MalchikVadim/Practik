﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Vadim.Ticket;
using Vadim.Classes;

namespace Vadim.Ticket
{
    /// <summary>
    /// Логика взаимодействия для dore.xaml
    /// </summary>
    public partial class dore : Page
    {
        private TicketBD _currentItem = new TicketBD();
        public dore(TicketBD selectedItem)
        {
            InitializeComponent();
            if (selectedItem != null)
            {
                _currentItem = selectedItem;
                Titletxt.Text = "Изменение";
            }
            // Создаём контекст
            DataContext = _currentItem;
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.idBook))) error.AppendLine("Укажите название книги");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.idReader))) error.AppendLine("Укажите ФИО читателя");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.date_take))) error.AppendLine("Укажите дату выдачи");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.return_date))) error.AppendLine("Укажите дату возврата");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentItem.idTicket == 0)
            {
                LibraryEntities.GetContext().TicketBD.Add(_currentItem);
                try
                {
                    LibraryEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new ticket());
                    MessageBox.Show("Новый билет успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    LibraryEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new ticket());
                    MessageBox.Show("Билет успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new ticket());
        }
    }
}
