﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Vadim.Classes;
using Vadim.Ticket;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;

namespace Vadim.Ticket
{
    /// <summary>
    /// Логика взаимодействия для ticket.xaml
    /// </summary>
    public partial class ticket : Page
    {
        public ticket()
        {
            InitializeComponent();
            ety2.ItemsSource = LibraryEntities.GetContext().TicketBD.ToList();
        }

        private void BTNComeback_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(null);
        }

        private void knopka1_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new dore(null));
        }

        private void hgt2_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new dore((TicketBD)ety2.SelectedItem));
        }

        private void hgt1_Click(object sender, RoutedEventArgs e)
        {
            var itemForRemoving = ety2.SelectedItems.Cast<TicketBD>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {itemForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    LibraryEntities.GetContext().TicketBD.RemoveRange(itemForRemoving);
                    LibraryEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    ety2.ItemsSource = LibraryEntities.GetContext().TicketBD.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void MenuSortNameV1_Click(object sender, RoutedEventArgs e)
        {
            ety2.ItemsSource = LibraryEntities.GetContext().TicketBD.OrderBy(x => x.idBook).ToList();
        }

        private void MenuSortNameV2_Click(object sender, RoutedEventArgs e)
        {
            ety2.ItemsSource = LibraryEntities.GetContext().TicketBD.OrderByDescending(x => x.idBook).ToList();
        }

        private void SearchProduct_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (ety2.ItemsSource != null)
            {
                ety2.ItemsSource = LibraryEntities.GetContext().TicketBD.Where(x => x.BookBD.title.ToLower().Contains(SearchProduct.Text.ToLower())).ToList();
            }
            if (SearchProduct.Text.Count() == 0) ety2.ItemsSource = LibraryEntities.GetContext().TicketBD.ToList();
        }

        private void MenuExportToExcelProduct_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Договор.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[46, 2] = "Дата:";
            ws.Cells[46, 3] = DateTime.Now.ToString();
            ws.Cells[4, 6] = "Договор №777";
            int indexRows = 6;
            ws.Cells[2][4] = "Читательские билеты";
            ws.Cells[1][indexRows] = "№";
            ws.Cells[2][indexRows] = "Название книги";
            ws.Cells[3][indexRows] = "ФИО читателя";
            ws.Cells[4][indexRows] = "Дата выдачи";
            ws.Cells[5][indexRows] = "Дата возврата";
            var printItems = ety2.Items;
            foreach (TicketBD item in printItems)
            {
                ws.Cells[1][indexRows + 1] = indexRows - 5;
                ws.Cells[2][indexRows + 1] = item.BookBD.title;
                ws.Cells[3][indexRows + 1] = item.ReaderBD.fio;
                ws.Cells[4][indexRows + 1] = item.date_take;
                ws.Cells[5][indexRows + 1] = item.return_date;
                indexRows++;
            }
            ws.Columns.AutoFit();
            ws.Cells[indexRows + 2, 7] = "Подпись";
            ws.Cells[indexRows + 2, 8] = "Мальчик В.В.";
            excelApp.Visible = true;
        }
    }
}
