﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Vadim.Classes;
using Vadim.Ticket;

namespace Vadim.Ticket
{
    /// <summary>
    /// Логика взаимодействия для ticket.xaml
    /// </summary>
    public partial class ticket : Page
    {
        public ticket()
        {
            InitializeComponent();
            ety2.ItemsSource = LibraryEntities.GetContext().TicketBD.ToList();
        }

        private void BTNComeback_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(null);
        }

        private void knopka1_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new dore(null));
        }

        private void hgt2_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new dore((TicketBD)ety2.SelectedItem));
        }

        private void hgt1_Click(object sender, RoutedEventArgs e)
        {
            var itemForRemoving = ety2.SelectedItems.Cast<TicketBD>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {itemForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    LibraryEntities.GetContext().TicketBD.RemoveRange(itemForRemoving);
                    LibraryEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    ety2.ItemsSource = LibraryEntities.GetContext().TicketBD.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void MenuSortNameV1_Click(object sender, RoutedEventArgs e)
        {
            ety2.ItemsSource = LibraryEntities.GetContext().TicketBD.OrderBy(x => x.idBook).ToList();
        }

        private void MenuSortNameV2_Click(object sender, RoutedEventArgs e)
        {
            ety2.ItemsSource = LibraryEntities.GetContext().TicketBD.OrderByDescending(x => x.idBook).ToList();
        }

        private void SearchProduct_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (ety2.ItemsSource != null)
            {
                ety2.ItemsSource = LibraryEntities.GetContext().TicketBD.Where(x => x.BookBD.title.ToLower().Contains(SearchProduct.Text.ToLower())).ToList();
            }
            if (SearchProduct.Text.Count() == 0) ety2.ItemsSource = LibraryEntities.GetContext().TicketBD.ToList();
        }
    }
}
