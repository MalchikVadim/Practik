﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Vadim.Classes;
using Vadim.Book;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;


namespace Vadim.Book
{
    /// <summary>
    /// Логика взаимодействия для book.xaml
    /// </summary>
    public partial class book : Page
    {
        public book()
        {
            InitializeComponent();
            ety1.ItemsSource = LibraryEntities.GetContext().BookBD.ToList();
        }

        private void BTNComeback_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(null);
        }

        private void knopka1_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new dobred(null));
        }

        private void hgt2_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new dobred((BookBD)ety1.SelectedItem));
        }

        private void hgt1_Click(object sender, RoutedEventArgs e)
        {
            var itemForRemoving = ety1.SelectedItems.Cast<BookBD>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {itemForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    LibraryEntities.GetContext().BookBD.RemoveRange(itemForRemoving);
                    LibraryEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    ety1.ItemsSource = LibraryEntities.GetContext().BookBD.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
        private void MenuSortDescProduct1_Click(object sender, RoutedEventArgs e)
        {
            ety1.ItemsSource = LibraryEntities.GetContext().BookBD.OrderBy(x => x.title).ToList();
        }

        private void MenuSortDescProduct2_Click(object sender, RoutedEventArgs e)
        {
            ety1.ItemsSource = LibraryEntities.GetContext().BookBD.OrderByDescending(x => x.title).ToList();
        }

        private void MenuFilterProduct1_Click(object sender, RoutedEventArgs e)
        {
            ety1.ItemsSource = LibraryEntities.GetContext().BookBD.Where(x => x.pages >= 0 && x.pages <= 100).ToList();
        }

        private void MenuFilterProduct2_Click(object sender, RoutedEventArgs e)
        {
            ety1.ItemsSource = LibraryEntities.GetContext().BookBD.Where(x => x.pages >= 101 && x.pages <= 500).ToList();
        }

        private void MenuFilterProduct3_Click(object sender, RoutedEventArgs e)
        {
            ety1.ItemsSource = LibraryEntities.GetContext().BookBD.Where(x => x.pages >= 501).ToList();
        }

        private void SearchProduct_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (ety1.ItemsSource != null)
            {
                ety1.ItemsSource = LibraryEntities.GetContext().BookBD.Where(x => x.Author.FIO.ToLower().Contains(SearchProduct.Text.ToLower())).ToList();
            }
            if (SearchProduct.Text.Count() == 0) ety1.ItemsSource = LibraryEntities.GetContext().BookBD.ToList();
        }

        private void MenuExportToExcelProduct_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Договор.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[46, 2] = "Дата:";
            ws.Cells[46, 3] = DateTime.Now.ToString();
            ws.Cells[4, 6] = "Договор №777";
            int indexRows = 6;
            ws.Cells[2][4] = "Книги";
            ws.Cells[1][indexRows] = "№";
            ws.Cells[2][indexRows] = "Название";
            ws.Cells[3][indexRows] = "Жанр";
            ws.Cells[4][indexRows] = "Кол-во страниц";
            ws.Cells[5][indexRows] = "Цена";
            ws.Cells[6][indexRows] = "Автор";
            ws.Cells[7][indexRows] = "Год издания";
            var printItems = ety1.Items;
            foreach (BookBD item in printItems)
            {
                ws.Cells[1][indexRows + 1] = indexRows - 5;
                ws.Cells[2][indexRows + 1] = item.title;
                ws.Cells[3][indexRows + 1] = item.Genre.Namegenre;
                ws.Cells[4][indexRows + 1] = item.pages;
                ws.Cells[5][indexRows + 1] = item.price;
                ws.Cells[6][indexRows + 1] = item.Author.FIO;
                ws.Cells[7][indexRows + 1] = item.year;
                indexRows++;
            }
            ws.Columns.AutoFit();
            ws.Cells[indexRows + 2, 7] = "Подпись";
            ws.Cells[indexRows + 2, 8] = "Мальчик В.В.";
            excelApp.Visible = true;
        }
    }
}
