﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Vadim.Book;
using Vadim.Classes;
namespace Vadim.Classes
{
    /// <summary>
    /// Логика взаимодействия для dobred.xaml
    /// </summary>
    public partial class dobred : Page
    {
        private BookBD _currentItem = new BookBD();
        public dobred(BookBD selectedItem)
        {
            InitializeComponent();
            if (selectedItem != null)
            {
                _currentItem = selectedItem;
                Titletxt.Text = "Изменение";
            }
            // Создаём контекст
            DataContext = _currentItem;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentItem.title)) error.AppendLine("Укажите название книги");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.idGenre))) error.AppendLine("Укажите жанр");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.pages))) error.AppendLine("Укажите кол-во страниц");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.price))) error.AppendLine("Укажите цену");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.idAuthor))) error.AppendLine("Укажите автора");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.year))) error.AppendLine("Укажите год издания");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentItem.idBook == 0)
            {
                LibraryEntities.GetContext().BookBD.Add(_currentItem);
                try
                {
                    LibraryEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new book());
                    MessageBox.Show("Новая книга успешно добавлена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    LibraryEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new book());
                    MessageBox.Show("Книга успешно изменена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new book());
        }
    }
}
